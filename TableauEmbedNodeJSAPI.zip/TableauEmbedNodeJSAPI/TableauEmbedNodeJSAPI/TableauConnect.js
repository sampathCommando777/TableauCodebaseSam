﻿const jsdom = require("jsdom");



const { JSDOM } = jsdom;



const dom = new JSDOM(

  <script src="https://public.tableau.com/javascripts/api/tableau-2.1.1.min.js" type="text/javascript"></script>

  <script>

  var startTime = Math.floor(Date.now());

  run_viz();

  function run_viz(){

    //load the viz

    var viz, workbook;

    var vizDiv = document.getElementById('tableau');

    var vizURL = "https://public.tableau.com/views/USvsTHEM/USvs_THEM";

    var options = {

        width: '200px',

        height: '200px',

        //these options change performance

        hideToolbar: true,

        hideTabs: true,

        onFirstInteractive: function () {

            getAudit();

        }

    };

    viz = new tableauSoftware.Viz(vizDiv, vizURL, options);

}

 

function getAudit(){

        //clock time from start to loaded

        console.log('loaded in '+(Math.floor(Date.now())-startTime)+' ms');

   

        //gather info

        console.log(viz.getWorkbook().getName());

        console.log(viz.getWorkbook().getParametersAsync());

}

  </script>

    <body></body>
{ runScripts: "dangerously" });